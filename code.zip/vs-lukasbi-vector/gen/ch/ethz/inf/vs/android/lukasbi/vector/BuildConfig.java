/** Automatically generated file. DO NOT MODIFY */
package ch.ethz.inf.vs.android.lukasbi.vector;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}